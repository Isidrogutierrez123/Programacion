def mostrar_cuadrado(lado):
    #Muestra la figura con *
    for i in range(int(lado)):
        print("* " * int(lado))

    area = lado * lado
    perimetro = 4 * lado
    print(f"Su área es {area}")
    print(f"Su perímetro es {perimetro}")

def mostrar_rectangulo(base, altura):
    #Muestra la figura con *
    for i in range(int(altura)):
        print("* " * int(base))

    # Calcula el área y el perímetro
    area = base * altura
    perimetro = 2 * (base + altura)
    print(f"Su área es {area}")
    print(f"Su perímetro es {perimetro}")

def menu():
    while True:
        print("Ejecución Iniciada")
        print("Menú")
        print("1 - Cuadrado")
        print("2 - Rectángulo")

        opcion = input("Dime una opción: ")

        if opcion == "1":
            lado = int(input("Dime el lado del cuadrado: "))
            mostrar_cuadrado(lado)
            break
        elif opcion == "2":
            base = int(input("Dime la base del rectángulo: "))
            altura = int(input("Dime la altura del rectángulo: "))
            mostrar_rectangulo(base, altura)
            break
        else:
            #Informar de error sino elige una de las 2 opciones anteriores
            print("Opción incorrecta, intenta de nuevo.")

# Inicio del menú
menu()
