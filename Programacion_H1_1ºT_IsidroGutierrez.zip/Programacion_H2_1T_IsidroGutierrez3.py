def cuenta_bancaria():
    # Preguntar el saldo al usuario
    saldo = -1
    while saldo < 0:
        try:
            saldo = float(input("Introduce el saldo inicial de la cuenta: "))
            if saldo < 0:
                print("El saldo no puede ser negativo, intenta nuevamente.")
        except ValueError:
            print("Debes ingresar un número válido.")

    # Bucle para el menú
    while True:
        print("\n--- Menú de opciones ---")
        print("1. Ingresar dinero")
        print("2. Retirar dinero")
        print("3. Mostrar saldo")
        print("4. Salir")

        # Pedir una opción válida
        opcion = input("Elige una opción (1-4): ")

        # Opción 1: Ingresar dinero
        if opcion == '1':
            try:
                cantidad = float(input("¿Cuánto dinero deseas ingresar?: "))
                if cantidad > 0:
                    saldo += cantidad
                    print(f"Has ingresado {cantidad} €. Saldo actual: {saldo} €.")
                else:
                    print("No puedes ingresar una cantidad negativa o cero.")
            except ValueError:
                print("Debes ingresar un número válido.")

        # Opción 2: Retirar dinero
        elif opcion == '2':
            try:
                cantidad = float(input("¿Cuánto dinero deseas retirar?: "))
                if cantidad > 0:
                    if cantidad <= saldo:
                        saldo -= cantidad
                        print(f"Has retirado {cantidad} €. Saldo actual: {saldo} €.")
                    else:
                        print("No puedes retirar más dinero del que tienes en la cuenta.")
                else:
                    print("No puedes retirar una cantidad negativa o cero.")
            except ValueError:
                print("Debes ingresar un número válido.")

        # Opción 3: Mostrar saldo
        elif opcion == '3':
            print(f"Tu saldo actual es: {saldo} €.")

        # Opción 4: Salir
        elif opcion == '4':
            print("Gracias por usar nuestro servicio. ¡Hasta luego!")
            break

        # Si la opción no es válida
        else:
            print("Opción no válida, elige una opción entre 1 y 4.")

cuenta_bancaria()
