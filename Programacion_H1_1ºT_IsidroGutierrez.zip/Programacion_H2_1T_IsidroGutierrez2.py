import random

# Inicio de las puntuaciones
puntos_jugador = 0
puntos_maquina = 0

# Opciones del juego
opciones = {1: "Piedra", 2: "Papel", 3: "Tijera"}

# Bucle principal del juego
while puntos_jugador < 3 and puntos_maquina < 3:
    print("\n*** Nueva ronda ***\n")

    # El usuario tendrá que elegir la opcion del juego
    jugador = input("Elige 1 para Piedra, 2 para Papel, 3 para Tijera: ")

    # Si el jugador no elige una opcion válida, dara error
    if jugador not in ['1', '2', '3']:
        print("Opción incorrecta, elige otra vez.")
        continue

    jugador = int(jugador)

    # La máquina elige aleatoriamente un número entre 1 y 3
    maquina = random.randint(1, 3)

    print(f"Has elegido: {opciones[jugador]}")
    print(f"La máquina ha elegido: {opciones[maquina]}")

    # Resultado de la ronda
    if jugador == maquina:
        print("¡Empate!")
    elif (jugador == 1 and maquina == 3) or (jugador == 2 and maquina == 1) or (jugador == 3 and maquina == 2):
        print("¡Ganaste esta ronda!")
        puntos_jugador += 1
        # Victoria para el jugador
    else:
        print("La máquina ganó esta ronda.")
        puntos_maquina += 1
        # Victoria para la maquina

    print(f"Puntuación: Jugador {puntos_jugador} - Máquina {puntos_maquina}")

# Mostrar el ganador final
if puntos_jugador == 3:
    print("\n¡Felicidades! Has ganado la partida.")
else:
    print("\nLa máquina ha ganado la partida.")
