package HitoParte1;

public abstract class Animal {
    int numeroChip;
    String nombre;
    int edad;
    String raza;
    boolean adoptado = false;
    Persona adoptante;

    public Animal(int numeroChip, String nombre, int edad, String raza) {
        this.numeroChip = numeroChip;
        this.nombre = nombre;
        this.edad = edad;
        this.raza = raza;
    }

    public void adoptar(Persona p) {
        this.adoptado = true;
        this.adoptante = p;
    }

    public boolean estaAdoptado() {
        return adoptado;
    }

    public abstract void mostrar();
}
