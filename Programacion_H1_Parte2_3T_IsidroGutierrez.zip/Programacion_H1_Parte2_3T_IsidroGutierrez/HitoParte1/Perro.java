package HitoParte1;

public class Perro extends Animal {
    public Perro(int numeroChip, String nombre, int edad, String raza) {
        super(numeroChip, nombre, edad, raza);
    }

    @Override
    public void mostrar() {
        System.out.println("Perro - Chip: " + numeroChip + ", Nombre: " + nombre + ", Edad: " + edad + ", Raza: " + raza + (adoptado ? " (Adoptado)" : ""));
    }
}
