package HitoParte1;

public class Gato extends Animal {
    String testLeucemia;

    public Gato(int numeroChip, String nombre, int edad, String raza, String testLeucemia) {
        super(numeroChip, nombre, edad, raza);
        this.testLeucemia = testLeucemia;
    }

    @Override
    public void mostrar() {
        System.out.println("Gato - Chip: " + numeroChip + ", Nombre: " + nombre + ", Edad: " + edad + ", Raza: " + raza + ", Test: " + testLeucemia + (adoptado ? " (Adoptado)" : ""));
    }

    public String getTestLeucemia() {
        return testLeucemia;
    }
}
