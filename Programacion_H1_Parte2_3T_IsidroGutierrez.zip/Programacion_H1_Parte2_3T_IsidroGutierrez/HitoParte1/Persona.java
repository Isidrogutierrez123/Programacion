package HitoParte1;

public class Persona {
    String dni;
    String nombre;
    String telefono;

    public Persona(String dni, String nombre, String telefono) {
        this.dni = dni;
        this.nombre = nombre;
        this.telefono = telefono;
    }
}
