package HitoParte1;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Listas para animales y personas
        ArrayList<Animal> listaAnimales = new ArrayList<>();
        ArrayList<Persona> listaPersonas = new ArrayList<>();

        // Ejemplos
        listaAnimales.add(new Gato(1002, "Misu", 2, "Egipto", "negativo"));
        listaAnimales.add(new Gato(1004, "Luna", 1, "Siames", "positivo"));
        listaAnimales.add(new Perro(1006, "Guau", 2, "Chiguagua"));
        listaAnimales.add(new Perro(1008, "Kira", 1, "Labrador"));
        listaPersonas.add(new Persona("12345678A", "Juan Pérez", "612345678"));
        listaPersonas.add(new Persona("23456789B", "Ana Gómez", "623456789"));

        // scanner para las entradas del usuario
        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        // Menú principal 
        while (!salir) {
            mostrarMenu();
            int opcion = scanner.nextInt();
            switch (opcion) {
                case 1: darDeAltaAnimal(listaAnimales, scanner); break; 
                case 2: listarAnimales(listaAnimales); break; 
                case 3: buscarAnimal(listaAnimales, scanner); break; 
                case 4: realizarAdopcion(listaAnimales, listaPersonas, scanner); break; 
                case 5: darDeBaja(listaAnimales, scanner); break; 
                case 6: mostrarEstadisticasDeGatos(listaAnimales); break; 
                case 7: salir = true; break; // Salir del programa
                default: System.out.println("Opción no válida."); // Mensaje si la opción no es válida
            }
        }
        scanner.close(); // Cerrar el scanner 
    }

    // Menu
    private static void mostrarMenu() {
        System.out.println("\nMenu:");
        System.out.println("1 - Dar de alta animal");
        System.out.println("2 - Listar animales");
        System.out.println("3 - Buscar animal");
        System.out.println("4 - Realizar adopción");
        System.out.println("5 - Dar de baja");
        System.out.println("6 - Mostrar estadísticas de gatos");
        System.out.println("7 - Salir");
        System.out.print("Selecciona una opción: ");
    }

    // Dar de alta nuevo animal
    private static void darDeAltaAnimal(ArrayList<Animal> listaAnimales, Scanner scanner) {
        scanner.nextLine(); // Limpiar buffer
        System.out.print("Número de chip: ");
        int chip = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine(); 
        System.out.print("Raza: ");
        String raza = scanner.nextLine();
        System.out.print("¿Es un perro o un gato? (perro/gato): ");
        String tipo = scanner.nextLine().toLowerCase();

        // Questiones para el tipo de animal
        if (tipo.equals("perro")) {
            listaAnimales.add(new Perro(chip, nombre, edad, raza)); // Agregar perro
        } else if (tipo.equals("gato")) {
            System.out.print("¿Resultado del test de leucemia? (positivo/negativo): ");
            String testLeucemia = scanner.nextLine();
            listaAnimales.add(new Gato(chip, nombre, edad, raza, testLeucemia)); // Agregar gato
        } else {
            System.out.println("Tipo no válido. No se pudo dar de alta el animal.");
        }

        System.out.println("Animal dado de alta correctamente.");
    }

    // listar todos los animales registrados
    private static void listarAnimales(ArrayList<Animal> listaAnimales) {
        if (listaAnimales.isEmpty()) {
            System.out.println("No hay animales registrados.");
        } else {
            listaAnimales.forEach(Animal::mostrar); // muestra cada animal en la lista
        }
    }

    // buscar animal por su chip
    private static void buscarAnimal(ArrayList<Animal> listaAnimales, Scanner scanner) {
        System.out.print("Introduce el número de chip del animal: ");
        int chip = scanner.nextInt();
        Animal animal = buscarPorChip(listaAnimales, chip); // Buscar el animal
        if (animal != null) animal.mostrar(); // lo muestra
        else System.out.println("No se encontró el animal.");
    }

    // Adoptar un animal
    private static void realizarAdopcion(ArrayList<Animal> listaAnimales, ArrayList<Persona> listaPersonas, Scanner scanner) {
        System.out.print("Introduce el número de chip del animal para adoptar: ");
        int chip = scanner.nextInt();
        Animal animal = buscarPorChip(listaAnimales, chip); // Buscar el animal por chip
        if (animal != null) {
            if (animal.estaAdoptado()) {
                System.out.println("Este animal ya ha sido adoptado.");
            } else {
                scanner.nextLine(); // Limpiar buffer
                System.out.print("Introduce el DNI del adoptante: ");
                String dni = scanner.nextLine();
                System.out.print("Introduce el nombre del adoptante: ");
                String nombre = scanner.nextLine();
                System.out.print("Introduce el teléfono del adoptante: ");
                String telefono = scanner.nextLine();
                Persona adoptante = new Persona(dni, nombre, telefono); // Crear persona adoptante
                listaPersonas.add(adoptante); // Añadir adoptante a la lista
                animal.adoptar(adoptante); // hacer la adopcion
                System.out.println("Adopción realizada con éxito.");
            }
        } else {
            System.out.println("No se encontró el animal.");
        }
    }

    // Función para dar de baja un animal
    private static void darDeBaja(ArrayList<Animal> listaAnimales, Scanner scanner) {
        System.out.print("Introduce el número de chip para dar de baja el animal: ");
        int chip = scanner.nextInt();
        Animal animal = buscarPorChip(listaAnimales, chip); // Buscar el animal por chip
        if (animal != null) {
            listaAnimales.remove(animal); // Eliminar el animal de la lista
            System.out.println("Animal dado de baja.");
        } else {
            System.out.println("No se encontró el animal.");
        }
    }

    //  estadísticas sobre los gatos
    private static void mostrarEstadisticasDeGatos(ArrayList<Animal> listaAnimales) {
        long totalGatos = 0;
        long gatosConLeucemia = 0;

        // Contamos los gatos y los gatos con leucemia positiva
        for (Animal a : listaAnimales) {
            if (a instanceof Gato) {
                totalGatos++;
                Gato g = (Gato) a;
                if (g.getTestLeucemia().equalsIgnoreCase("positivo")) {
                    gatosConLeucemia++;
                }
            }
        }

        // Mostrar estadísticas
        System.out.println("Número total de gatos: " + totalGatos);
        System.out.println("Gatos con test de leucemia positivo: " + gatosConLeucemia);
    }

    // Función para buscar un animal por chip
    private static Animal buscarPorChip(ArrayList<Animal> lista, int chip) {
        return lista.stream().filter(a -> a.numeroChip == chip).findFirst().orElse(null); // por chip
    }
}
