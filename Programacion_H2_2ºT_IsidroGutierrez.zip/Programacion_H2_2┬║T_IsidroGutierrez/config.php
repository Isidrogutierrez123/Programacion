<?php
// config.php



// Intentar la conexión a la base de datos MySQL con PDO
try {
    // Reemplaza estos valores con los de tu base de datos
    $pdo = new PDO('mysql:host=localhost;dbname=task_manager', 'root', 'curso'); 
    // Establece el modo de errores para PDO
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Si hay un error, lo muestra
    echo "Error de conexión: " . $e->getMessage();
}
?>
