<?php
// conexión a la base de datos 
include('config.php');  

// Verificar si el formulario de login ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos enviados desde el formulario
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Verificar si los campos de email y contraseña no están vacíos
    if (!empty($email) && !empty($password)) {
        // Preparar la consulta SQL para buscar al usuario en la base de datos usando el email
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();  // Obtener el usuario si existe

        // Verificar si el usuario existe y si la contraseña coincide (usando password_verify)
        if ($user && password_verify($password, $user['password'])) {
            // Iniciar sesión para este usuario
            session_start();
            $_SESSION['user_id'] = $user['id'];  // Guardar el ID del usuario en la sesión
            $_SESSION['username'] = $user['username'];  // Guardar el nombre de usuario en la sesión
            header("Location: tasks.php");  // Redirigir al usuario a la página de tareas
            exit;  // Asegurarse de que el código posterior no se ejecute
        } else {
            // Mostrar un mensaje de error si el correo electrónico o la contraseña son incorrectos
            echo "<p style='color:red;'>Correo electrónico o contraseña incorrectos.</p>";
        }
    } else {
        // Mostrar un mensaje de error si los campos están vacíos
        echo "<p style='color:red;'>Por favor, completa ambos campos.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <style>
        /* Estilos para la página de login */
        body {
            font-family: Arial, sans-serif;  /* Fuente de la página */
            background-color: #f0f8ff;  /* Color de fondo */
            display: flex;
            justify-content: center;  
            align-items: center;  
            height: 100vh;  
            margin: 0;  /* Eliminar márgenes predeterminados */
        }

        /* Estilo para el contenedor principal del formulario */
        .login-container {
            background-color: #fff;  /* Fondo blanco */
            padding: 20px;  
            border-radius: 8px;  /* Bordes redondeados */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);  /* Sombra para dar efecto de profundidad */
            width: 300px;  
            text-align: center;  /* Centrar el texto dentro del contenedor */
        }

        /* Estilo para el título del formulario */
        .login-container h2 {
            color: #4CAF50;  /* Color verde para el título */
            margin-bottom: 20px;  /* Separación debajo del título */
        }

        /* Estilo para las etiquetas de los campos del formulario */
        .login-container label {
            font-size: 14px;  /* Tamaño de fuente de las etiquetas */
            color: #333;  
            display: block;  
            margin-bottom: 5px;  /* Separación debajo de las etiquetas */
        }

        /* Estilo para los campos de entrada (email y contraseña) */
        .login-container input[type="email"],
        .login-container input[type="password"] {
            width: 100%;  
            padding: 10px;  
            margin: 10px 0;  /* Separación entre los campos */
            border: 1px solid #ccc;  /* Borde gris claro */
            border-radius: 4px;  
            box-sizing: border-box;  
        }

        /* Estilo para el botón de envío */
        .login-container button {
            background-color: #4CAF50;  
            color: white;  /* Color del texto blanco */
            padding: 10px;  
            border: none;  /* Eliminar borde por defecto */
            border-radius: 4px;  /* Bordes redondeados */
            width: 100%;  
            font-size: 16px;  
            cursor: pointer;  
        }

        /* Estilo para el botón al pasar el cursor por encima */
        .login-container button:hover {
            background-color: #45a049;  
        }

        /* Estilo para el párrafo con el enlace de registro */
        .login-container p {
            margin-top: 20px;  
        }

        /* Estilo para el enlace de "¿No tienes cuenta?" */
        .login-container p a {
            color: #4CAF50;  
            text-decoration: none;  
        }

        .login-container p a:hover {
            text-decoration: underline;  
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Iniciar sesión</h2>
    <!-- Formulario de login -->
    <form method="POST" action="login.php">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>  

        <label for="password">Contraseña:</label>
        <input type="password" name="password" id="password" required>  

        <button type="submit">Iniciar sesión</button> 
    </form>

    
    <p>¿No tienes cuenta? <a href="register.php">Regístrate aquí</a></p>
</div>

</body>
</html>
