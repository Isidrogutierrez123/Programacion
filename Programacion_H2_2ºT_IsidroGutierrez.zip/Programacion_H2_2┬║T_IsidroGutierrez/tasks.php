<?php
session_start();  // Inicia la sesión

require 'db.php';  // Conexión a la base de datos

// Verificar si el usuario está autenticado
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");  // Redirige a la página de login si no está autenticado
    exit();  // Detiene la ejecución del código
}

$user_id = $_SESSION["user_id"]; // Obtiene el ID del usuario desde la sesión

// Manejar la adición de nuevas tareas
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["task"])) {
    $task = trim($_POST["task"]);  // Obtiene la tarea del formulario

    // Verifica que la tarea no esté vacía
    if (!empty($task)) {
        // Prepara la consulta para insertar una nueva tarea en la base de datos
        $stmt = $conn->prepare("INSERT INTO tasks (user_id, task) VALUES (?, ?)");
        $stmt->bind_param("is", $user_id, $task); // Asocia los parámetros
        if ($stmt->execute()) {  // Si la inserción es exitosa
            echo "<script>alert('Tarea agregada correctamente.'); window.location.href='tasks.php';</script>";  // Muestra un mensaje y redirige
        } else {
            echo "<script>alert('Error al agregar la tarea.');</script>";  
        }
        $stmt->close();  // Cierra la consulta
    }
}

// Eliminar tarea
if (isset($_GET['delete'])) {  // Si se ha enviado una solicitud para eliminar una tarea
    $task_id = $_GET['delete'];  // Obtiene el ID de la tarea a eliminar

    // Prepara la consulta para eliminar la tarea
    $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $task_id, $user_id); // Asocia los parámetros
    if ($stmt->execute()) {  // Si la tarea se elimina correctamente
        echo "<script>alert('Tarea eliminada correctamente.'); window.location.href='tasks.php';</script>";  
    } else {
        echo "<script>alert('Error al eliminar la tarea.'); window.location.href='tasks.php';</script>";  // Muestra un mensaje de error si falla
    }
    $stmt->close();  // Cierra la consulta
}

// Obtener las tareas del usuario
$stmt = $conn->prepare("SELECT id, task FROM tasks WHERE user_id = ?");  // Prepara la consulta para obtener las tareas
$stmt->bind_param("i", $user_id);  // Asocia el ID del usuario
$stmt->execute();  // Ejecuta la consulta
$result = $stmt->get_result();  // Obtiene el resultado de la consulta
$tasks = $result->fetch_all(MYSQLI_ASSOC);  // Recupera todas las tareas
$stmt->close();  // Cierra la consulta
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Tareas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 50px;
            text-align: center;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            display: inline-block;
            width: 400px;
        }
        h2 {
            color: #333;
        }
        input {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            text-decoration: none;
            color: white;
            background: #28a745;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: #218838;
        }
        .tasks {
            margin-top: 20px;
        }
        .task {
            background: #f9f9f9;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
        }
        .task a {
            margin-left: 10px;
            color: #007bff;
            text-decoration: none;
        }
        .task a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Mis Tareas</h2>
        
        <form action="tasks.php" method="POST">
            <input type="text" name="task" placeholder="Nueva tarea" required>
            <button type="submit" class="btn">Agregar tarea</button>
        </form>

        <div class="tasks">
            <h3>Tareas Pendientes</h3>
            <?php if (count($tasks) > 0): ?>
                <?php foreach ($tasks as $task): ?>
                    <div class="task">
                        <?php echo htmlspecialchars($task['task']); ?>
                        <!-- Botón de eliminar tarea -->
                        <a href="tasks.php?delete=<?php echo $task['id']; ?>" onclick="return confirm('¿Estás seguro de que deseas eliminar esta tarea?');">Eliminar</a>
                        <!-- Botón para modificar tarea -->
                        <a href="edit_task.php?id=<?php echo $task['id']; ?>">Modificar</a>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No tienes tareas pendientes.</p>
            <?php endif; ?>
        </div>

        <br>
        <a href="logout.php">Cerrar sesión</a>
    </div>
</body>
</html>
