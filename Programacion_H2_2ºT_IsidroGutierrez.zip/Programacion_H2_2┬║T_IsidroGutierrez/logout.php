<?php
// Iniciar la sesión 
session_start();


session_unset();  // Elimina todas las variables de sesión actualmente registradas


session_destroy();  // Borra la sesión de la memoria del servidor


header("Location: inicio.php");  // Redirige a la página de inicio después de cerrar sesión


exit();  // Detiene la ejecución del código después de la redirección
?>
