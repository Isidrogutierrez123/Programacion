<?php

session_start();

// Verificar si el usuario ya ha iniciado sesión. Si es así, redirigirlo a la página de tareas
if (isset($_SESSION['user_id'])) {
    // Redirigir al usuario a la página de tareas si ya está autenticado
    header("Location: tasks.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas</title>
    <style>
        /* Estilos generales para la página */
        body {
            font-family: Arial, sans-serif;  
            text-align: center;  /* Centrar el contenido */
            background-color: #f4f4f4;  
            padding: 50px;  
        }

        
        .container {
            background: white;  
            padding: 20px;  
            border-radius: 10px;  /* Bordes redondeados */
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);  /* Sombra alrededor del contenedor */
            display: inline-block;  
        }

        /* Estilo para los encabezados */
        h2 {
            color: #333;  
        }

        /* Estilo para los botones */
        .btn {
            display: inline-block;  
            padding: 10px 20px;  /* Tamaño del botón */
            margin: 10px;  
            text-decoration: none;  /* Eliminar subrayado de los enlaces */
            color: white;  
            background: #007BFF;  
            border-radius: 5px;  
        }

        /* Estilo para los botones cuando se pasa el cursor por encima */
        .btn:hover {
            background: #0056b3;  /* Cambiar el color de fondo al pasar el mouse */
        }
    </style>
</head>
<body>
    <div class="container">
    
        <h2>Bienvenido a la Gestión de Tareas</h2>
        
       
        <p>Administra tus tareas de forma sencilla.</p>
        
        
        <a href="register.php" class="btn">Registrarse</a>
        
        
        <a href="login.php" class="btn">Iniciar Sesión</a>
    </div>
</body>
</html>
