<?php
session_start();  
require 'db.php';  

// Verificar si el formulario fue enviado a través de POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);  // Recibe y limpia el nombre de usuario
    $email = trim($_POST["email"]);  // Recibe y limpia el correo electrónico
    $password = trim($_POST["password"]);  // Recibe y limpia la contraseña

    // Verificar si todos los campos tienen datos
    if (!empty($username) && !empty($email) && !empty($password)) {
        // Verificar si el correo ya está registrado en la base de datos
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");  // Prepara la consulta SQL
        $stmt->bind_param("s", $email);  // Asocia el valor del correo
        $stmt->execute();  // Ejecuta la consulta
        $stmt->store_result();  // Almacena el resultado de la consulta

        // Si el correo ya existe
        if ($stmt->num_rows > 0) {
            $error = "El correo ya está registrado.";  // Error si el correo ya existe
        } else {
            // Si el correo no está registrado, se hashifica la contraseña
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            // Preparar la consulta para insertar al nuevo usuario en la base de datos
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);  // Asocia los valores al query
            if ($stmt->execute()) {  // Si la inserción es exitosa
                header("Location: register_success.php");  // Redirige a la página de éxito
                exit();  // Detiene la ejecución posterior
            } else {
                $error = "Error al registrar el usuario.";  // Si hubo error al insertar
            }
        }
        $stmt->close();  // Cierra la sentencia
    } else {
        $error = "Todos los campos son obligatorios.";  // Si faltan campos por completar
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  
    <title>Registro</title>  
    <style>
        /* Estilos generales para la página */
        body {
            font-family: Arial, sans-serif;  /* Fuente de la página */
            text-align: center;  
            background-color: #f4f4f4;  
            padding: 50px;  
        }
        /* Estilos para el contenedor de formulario */
        .container {
            background: white;  /* Color de fondo blanco */
            padding: 20px;  
            border-radius: 10px;  
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);  
            display: inline-block;  
            width: 300px;  
        }
        h2 {
            color: #333;  
        }
        /* Estilos para los campos de texto */
        input {
            width: 100%;  
            padding: 8px;  
            margin: 5px 0;  
            border: 1px solid #ccc;  
            border-radius: 5px;  
        }
        /* Estilos para el botón */
        .btn {
            display: block;  
            width: 100%;
            padding: 10px;  
            text-decoration: none;  /* Quitar subrayado */
            color: white;  
            background: #28a745;  /* Color de fondo verde */
            border-radius: 5px;  
            border: none;  
            cursor: pointer;  /* Cursor de tipo puntero */
        }
        .btn:hover {
            background: #218838;  
        }
        /* Estilos para los mensajes de error */
        .error {
            color: red;  
        }
    </style>
</head>
<body>
    
    <div class="container">
        <h2>Registro de Usuario</h2>
        <!-- Mostrar mensaje de error si existe -->
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <!-- Formulario de registro -->
        <form action="register.php" method="POST">
            <label>Nombre de Usuario:</label>
            <input type="text" name="username" required>  
            
            <label>Correo Electrónico:</label>
            <input type="email" name="email" required>  

            <label>Contraseña:</label>
            <input type="password" name="password" required>  

            <!--  para aceptar las políticas -->
            <input type="checkbox" id="politicas" name="politicas">
            <label for="politicas">Acepto las <a href="politicas.html" target="_blank">políticas de privacidad</a></label><br>

            <
            <button type="submit" class="btn">Registrarse</button>
        </form>
        <br>
        
        <a href="index.php">Volver</a>
    </div>
</body>
</html>
