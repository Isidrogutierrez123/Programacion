<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro Exitoso</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f4f4f4;
            padding: 50px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            display: inline-block;
            width: 300px;
        }
        h2 {
            color: #333;
        }
        .btn {
            display: block;
            width: 100%;
            padding: 10px;
            text-decoration: none;
            color: white;
            background: #28a745;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: #218838;
        }
        a {
            color: #28a745;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>¡Registro Exitoso!</h2>
        <p>Tu cuenta ha sido creada con éxito. Ahora puedes iniciar sesión.</p>
        <a href="inicio.php"><button class="btn">Volver al inicio</button></a>
    </div>
</body>
</html>
