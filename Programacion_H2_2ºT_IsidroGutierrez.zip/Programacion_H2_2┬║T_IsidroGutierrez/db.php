<?php
$servername = "localhost"; // Cambia esto si tu servidor no es local
$username = "root"; // Usuario de MySQL
$password = "curso"; // Contraseña de MySQL (déjala vacía si no tienes una)
$database = "task_manager"; // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $database);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
