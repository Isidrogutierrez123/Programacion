package Hito2;
import java.sql.*;
import java.util.Scanner;


public class CineApp {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opcion;

        // menu
        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1 - Ver películas");
            System.out.println("2 - Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    mostrarPeliculas(); // metodo para mostrar peliculas
                    break;
                case 2:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 2); 

        sc.close(); //cerrar scanner
    }

    // metodo para mostrar peliculas
    public static void mostrarPeliculas() {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // conexion a la base
            con = ConexionBD.conectar();

            if (con != null) {
                stmt = con.createStatement();

                //  une las tablas pelicula y genero
                String consulta = "SELECT p.id_pelicula, p.titulo, p.director, p.duracion, p.clasificacion, g.nombre AS genero " +
                                  "FROM pelicula p JOIN genero g ON p.id_genero = g.id_genero";

                rs = stmt.executeQuery(consulta); // ejecuta la consulta

                System.out.println("\n--- Películas disponibles ---");

                // muestra 
                while (rs.next()) {
                    System.out.printf("ID: %s | Título: %s | Director: %s | Duración: %d min | Clasificación: %s | Género: %s\n",
                            rs.getString("id_pelicula"),
                            rs.getString("titulo"),
                            rs.getString("director"),
                            rs.getInt("duracion"),
                            rs.getString("clasificacion"),
                            rs.getString("genero"));
                }

            } else {
                System.out.println("No se pudo establecer conexión.");
            }

        } catch (SQLException e) {
            System.out.println("Error al consultar la base de datos: " + e.getMessage());
        } finally {
            // cierre
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar recursos.");
            }
        }
    }
}
