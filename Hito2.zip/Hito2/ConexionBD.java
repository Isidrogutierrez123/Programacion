package Hito2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Clase encargada de conectarse a la base de datos MySQL
public class ConexionBD {

    // Método que realiza la conexión y devuelve el objeto Connection
    public static Connection conectar() {
        Connection con = null;
        try {
            // driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // conexion
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cine", "root", "curso");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cine", "root", "curso");

        } catch (ClassNotFoundException e) {
            System.out.println("No se encontró el driver JDBC.");
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }

        // devuelve la conexion
        return con;
    }
}
