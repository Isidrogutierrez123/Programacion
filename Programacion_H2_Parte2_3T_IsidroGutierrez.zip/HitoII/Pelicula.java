package HitoII;
public class Pelicula {

    private int id;
    private String titulo;
    private String director;
    private int anio;
    private String genero;
    private int duracion;
    private String sinopsis;
    
    // Constructor para la pelicula con los datos

    public Pelicula(int id, String titulo, String director, int anio, String genero, int duracion, String sinopsis) {
        this.id = id;
        this.titulo = titulo;
        this.director = director;
        this.anio = anio;
        this.genero = genero;
        this.duracion = duracion;
        this.sinopsis = sinopsis;
    }
    
 // metodos de obtener para acceder a los atributos de la película

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDirector() {
        return director;
    }

    public int getAnio() {
        return anio;
    }

    public String getGenero() {
        return genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public String getSinopsis() {
        return sinopsis;
    }
}
