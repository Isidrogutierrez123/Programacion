package HitoII;

import java.sql.*;
import java.util.Scanner;

public class CineApp {

 private static Scanner scanner = new Scanner(System.in);

 // metodo para mostrar todas las películas en la base de datos
 public static void verPeliculas() {
     String query = "SELECT * FROM peliculas";
     try (Connection con = ConexionDB.obtenerConexion(); 
          Statement stmt = con.createStatement(); 
          ResultSet rs = stmt.executeQuery(query)) {

         while (rs.next()) {
             System.out.println("ID: " + rs.getInt("id"));
             System.out.println("Título: " + rs.getString("titulo"));
             System.out.println("Director: " + rs.getString("director"));
             System.out.println("Año: " + rs.getInt("anio"));
             System.out.println("Género: " + rs.getString("genero"));
             System.out.println("Duración: " + rs.getInt("duracion"));
             System.out.println("Sinopsis: " + rs.getString("sinopsis"));
             System.out.println("-----------------------------");
         }
     } catch (SQLException e) {
         System.out.println("Error al obtener películas: " + e.getMessage());
     }
 }

 // metodo para añadir una pelicula nueva a la base
 public static void anadirPelicula() {
     System.out.print("Título: ");
     String titulo = scanner.nextLine();
     System.out.print("Director: ");
     String director = scanner.nextLine();
     System.out.print("Año: ");
     int anio = scanner.nextInt();
     scanner.nextLine(); 
     System.out.print("Género: ");
     String genero = scanner.nextLine();
     System.out.print("Duración: ");
     int duracion = scanner.nextInt();
     scanner.nextLine(); 
     System.out.print("Sinopsis: ");
     String sinopsis = scanner.nextLine();

     String query = "INSERT INTO peliculas (titulo, director, anio, genero, duracion, sinopsis) VALUES (?, ?, ?, ?, ?, ?)";
     try (Connection con = ConexionDB.obtenerConexion(); 
          PreparedStatement pstmt = con.prepareStatement(query)) {

         pstmt.setString(1, titulo);
         pstmt.setString(2, director);
         pstmt.setInt(3, anio);
         pstmt.setString(4, genero);
         pstmt.setInt(5, duracion);
         pstmt.setString(6, sinopsis);     

         if (pstmt.executeUpdate() > 0) {
             System.out.println("Película añadida.");
         }
     } catch (SQLException e) {
         System.out.println("Error al añadir película: " + e.getMessage());
     }
 }

 // metodo para eliminar una pelicula 
 public static void eliminarPelicula() {
     System.out.print("ID de la película a eliminar: ");
     int id = scanner.nextInt();
     scanner.nextLine(); // limpia 

     String query = "DELETE FROM peliculas WHERE id = ?";
     try (Connection con = ConexionDB.obtenerConexion(); 
          PreparedStatement pstmt = con.prepareStatement(query)) {

         pstmt.setInt(1, id);

         if (pstmt.executeUpdate() > 0) {
             System.out.println("Película eliminada.");
         } else {
             System.out.println("Película no encontrada.");
         }
     } catch (SQLException e) {
         System.out.println("Error al eliminar película: " + e.getMessage());
     }
 }

 // metodo para modificar  la pelicula
 public static void modificarPelicula() {
     System.out.print("ID de la película a modificar: ");
     int id = scanner.nextInt();
     scanner.nextLine(); 
     System.out.print("Nuevo título: ");
     String titulo = scanner.nextLine();
     System.out.print("Nuevo director: ");
     String director = scanner.nextLine();

     String query = "UPDATE peliculas SET titulo = ?, director = ? WHERE id = ?";
     try (Connection con = ConexionDB.obtenerConexion(); 
          PreparedStatement pstmt = con.prepareStatement(query)) {

         pstmt.setString(1, titulo);
         pstmt.setString(2, director);
         pstmt.setInt(3, id);

         if (pstmt.executeUpdate() > 0) {
             System.out.println("Película modificada.");
         } else {
             System.out.println("Película no encontrada.");
         }
     } catch (SQLException e) {
         System.out.println("Error al modificar película: " + e.getMessage());
     }
 }

 // metodo para el menu
 public static void mostrarMenu() {
     int opcion;
     do {
         System.out.println("\n--- MENÚ ---");
         System.out.println("1 – Ver Películas");
         System.out.println("2 – Añadir película");
         System.out.println("3 – Eliminar película");
         System.out.println("4 – Modificar película");
         System.out.println("5 – Salir");
         System.out.print("Elige una opción: ");
         opcion = scanner.nextInt();
         scanner.nextLine(); // limpia

         switch (opcion) {
             case 1: verPeliculas(); break;
             case 2: anadirPelicula(); break;
             case 3: eliminarPelicula(); break;
             case 4: modificarPelicula(); break;
             case 5: System.out.println("Adiós."); break;
             default: System.out.println("Opción incorrecta.");
         }
     } while (opcion != 5);
 }
}
