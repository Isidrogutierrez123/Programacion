package HitoII;
public class Main {

    public static void main(String[] args) {
        CineApp.mostrarMenu();
    }
}
